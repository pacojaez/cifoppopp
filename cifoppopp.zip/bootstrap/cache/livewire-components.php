<?php return array (
  'alert-notification' => 'App\\Http\\Livewire\\AlertNotification',
  'categoria-index' => 'App\\Http\\Livewire\\CategoriaIndex',
  'categoria-nav' => 'App\\Http\\Livewire\\CategoriaNav',
);