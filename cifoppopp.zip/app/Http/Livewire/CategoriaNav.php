<?php

namespace App\Http\Livewire;

use Livewire\Component;

class CategoriaNav extends Component
{
    public function render()
    {
        return view('livewire.categoria-nav');
    }
}
