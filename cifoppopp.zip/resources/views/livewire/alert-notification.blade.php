<div>
    <button
        wire:click="tellme"
        class="px-4 py-2 text-white bg-indigo-500 border rounded"
    >
        Tell me something
    </button>
</div>
